sap.ui.define([
	"art/bif/ur/controller/BaseController"
	], function(BaseController){
		
		return BaseController.extend("art.bif.ur.controller.App", {
			
			
		});
		
	});